from pydantic import BaseModel
from datetime import datetime

from typing import Optional

class EmployeeCreateModel(BaseModel):
    first_name: str
    middle_name: str
    last_name: str
    birthdate: datetime
    position: int
    rank: int


class EmployeeUpdateModel(BaseModel):
    id: int
    first_name: Optional[str]
    middle_name: Optional[str]
    last_name: Optional[str]
    birthdate: Optional[datetime]
    position: Optional[int]
    rank: Optional[int]


class RankCreateModel(BaseModel):
    id: str
    name: str
    preporatory_period: Optional[str]


class PositionCreateModel(BaseModel):
    id: str
    name: str
    group: str