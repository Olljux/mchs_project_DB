from sqlmodel import SQLModel, Field, Column, Relationship
from sqlalchemy.dialects import postgresql as pg

from typing import List
from datetime import datetime

class Employee(SQLModel, table=True):
    __tablename__ = "employees"

    id: int = Field(
        foreign_key="users.id",
        primary_key=True
    )

    first_name: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))
    middle_name: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))
    last_name: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))
    birthdate: datetime = Field(sa_column=Column(pg.DATE, nullable=False))
    
    position: int = Field(foreign_key="positions.id", nullable=True)
    rank: int = Field(foreign_key="ranks.id", nullable=True)
    
    user: List["User"] = Relationship(back_populates="employee")


class Rank(SQLModel, table=True):
    __tablename__ = "ranks"

    id: str = Field(
        sa_column=Column(
            pg.INTEGER, 
            primary_key=True,
            autoincrement=True
        )
    )
    name: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))
    preporatory_period: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=True))


class Position(SQLModel, table=True):
    __tablename__ = "positions"

    id: str = Field(
        sa_column=Column(
            pg.INTEGER, 
            primary_key=True,
            autoincrement=True
        )
    )
    name: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))
    group: str = Field(sa_column=Column(pg.VARCHAR(100), nullable=False))