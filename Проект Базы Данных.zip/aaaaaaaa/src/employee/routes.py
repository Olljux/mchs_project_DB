from fastapi import APIRouter, Depends, status
from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from src.auth.dependencies import AuthBearer

from src.auth.routes import user_access, admin_access
from .schemas import EmployeeUpdateModel

from src.database.main import get_session
from src.auth.models import User
from src.auth.dependencies import get_current_user

from .models import Employee, Rank, Position
from .service import EmployeeService


employee_router = APIRouter()
employee_service = EmployeeService()
auth = AuthBearer()


@employee_router.patch("/update/me/", status_code=status.HTTP_200_OK)
async def update_self(
    employee_schema: EmployeeUpdateModel,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    user: User = Depends(get_current_user),
    valid_role: bool = Depends(user_access)
):
    result = await employee_service.update_employee(session, employee_schema)
    return result


@employee_router.patch("/update/", status_code=status.HTTP_200_OK)
async def update_another_employee(
    employee_schema: EmployeeUpdateModel,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    result = employee_service.update_employee(session, employee_schema)
    return result


@employee_router.post("/create/rank/", status_code=status.HTTP_200_OK)
async def create_rank(
    rank_schema: Rank,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    result = await employee_service.create_rank(session, rank_schema)
    return result


@employee_router.post("/create/position/", status_code=status.HTTP_200_OK)
async def create_position(
    position_schema: Position,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    result = await employee_service.create_position(session, position_schema)
    return result


@employee_router.delete("/delete/{type}/{id}", status_code=status.HTTP_200_OK)
async def delete_rank_or_position(
    type: str,
    id: int,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    if type == "rank":
        result = await employee_service.delete_rank(session, id)
    elif type == "position":
        result = await employee_service.delete_position(session, id)
    else:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid type")
    return result