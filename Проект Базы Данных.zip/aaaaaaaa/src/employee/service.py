from fastapi import status
from fastapi.exceptions import HTTPException

from sqlmodel import select, update, delete
from sqlmodel.ext.asyncio.session import AsyncSession

from .models import Employee, Rank, Position
from .schemas import EmployeeUpdateModel, PositionCreateModel, RankCreateModel


class EmployeeService:

    async def get_employees(self, session: AsyncSession):
        stmt = select(Employee)
        employees = await session.exec(stmt)
        return employees
    

    async def get_employee(self, session: AsyncSession, id: int):
        stmt = select(Employee).where(Employee.id == id)
        result = await session.exec(stmt)

        employee = result.first()

        if not employee:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Employee not found")

        return employee
    

    async def employee_exists(self, session: AsyncSession, id: id):
        stmt = select(Employee).where(Employee.id == id)
        result = await session.exec(stmt)
        employee = result.first()

        return employee is not None
    

    async def create_employee(self, session: AsyncSession, employee_schema: EmployeeUpdateModel):
        '''Employee should be created upon user creation, not using this method'''
        employee_data = employee_schema.model_dump()
        employee = Employee(**employee_data)
        session.add(employee)
        await session.commit()
        return employee

    
    async def update_employee(self, session: AsyncSession, employee_schema: EmployeeUpdateModel):
        employee_data = employee_schema.model_dump()
        id = employee_data.pop("id")
        del employee_data["id"]

        stmt = update(Employee).where(Employee.id == id).values()
        await session.exec(stmt)
        await session.commit()
        return {"message": "Employee updated"}
    

    async def delete_employee(self, session: AsyncSession, id: int):
        '''Never use, unless needed for smth i dunno'''
        stmt = delete(Employee).where(Employee.id == id)
        await session.exec(stmt)
        await session.commit()
        return {"message": "Employee deleted"}
    

    async def create_rank(self, session: AsyncSession, rank_schema: RankCreateModel):
        rank_data = rank_schema.model_dump()
        rank = Rank(**rank_data)
        session.add(rank)
        await session.commit()
        return rank
    

    async def delete_rank(self, session: AsyncSession, id: int):
        stmt = delete(Rank).where(Rank.id == id)
        await session.exec(stmt)
        await session.commit()
        return {"message": "Rank deleted"}
    

    async def create_position(self, session: AsyncSession, position_schema: PositionCreateModel):
        position_data = position_schema.model_dump()
        position = Position(**position_data)
        session.add(position)
        await session.commit()
        return position
    

    async def delete_position(self, session: AsyncSession, id: int):
        stmt = delete(Position).where(Position.id == id)
        await session.exec(stmt)
        await session.commit()
        return {"message": "Position deleted"}