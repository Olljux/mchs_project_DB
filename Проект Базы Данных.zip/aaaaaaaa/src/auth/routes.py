from fastapi import APIRouter, Depends, status
from sqlmodel.ext.asyncio.session import AsyncSession

from src.database.main import get_session
from src.auth.dependencies import AuthBearer, RoleCheck
from .schemas import UserCreateModel, UserSignUpModel
from .service import AuthService
from .models import User


auth_router = APIRouter()
auth = AuthBearer()
auth_service = AuthService()

user_access = RoleCheck(["user","admin"])
admin_access = RoleCheck(["admin"])

@auth_router.post("/signup", status_code=status.HTTP_200_OK)
async def signup(
    user_schema: UserSignUpModel,
    session: AsyncSession = Depends(get_session)
):
    
    new_user = await auth_service.create_user(session, user_schema)
    return new_user


@auth_router.patch("/user/verify/{id}", status_code=status.HTTP_200_OK)
async def verify_user(
    id: int,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    return await auth_service.verify_user(session, id, True)


@auth_router.patch("/user/unverify/{id}", status_code=status.HTTP_200_OK)
async def verify_user(
    id: int,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    return await auth_service.verify_user(session, id, False)


@auth_router.delete("/user/delete/{id}", status_code=status.HTTP_200_OK)
async def delete_user(
    id: int,
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    valid_role: bool = Depends(admin_access)
):
    return await auth_service.delete_user(session, id)


@auth_router.get("/me", status_code=status.HTTP_200_OK)
async def get_all_users(
    session: AsyncSession = Depends(get_session),
    bearer: str = Depends(auth),
    user: User = Depends(user_access)
):
    return user.employee