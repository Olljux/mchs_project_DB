from pydantic import BaseModel
from typing import Optional

from datetime import datetime


class UserCreateModel(BaseModel):
    login: str
    pwd: str


class UserSignUpModel(BaseModel):
    login: str
    pwd: str
    first_name: str
    middle_name: str
    last_name: str
    birthdate: datetime
    admin_password: Optional[str] = None