from fastapi import status
from fastapi.exceptions import HTTPException

from sqlmodel import select, update, delete
from sqlmodel.ext.asyncio.session import AsyncSession

from .models import User
from .schemas import UserCreateModel, UserSignUpModel

from src.employee.models import Employee
from src.employee.schemas import EmployeeCreateModel

from .utils import generate_password_hash, verify_password
from src.config import AppSettings


class AuthService:

    async def user_exists(self, session: AsyncSession, id: id):
        stmt = select(User).where(User.id == id)
        result = await session.exec(stmt)

        return result.first() is not None
    

    async def get_user(self, session: AsyncSession, id: int):
        stmt = select(User).where(User.id == id)
        result = await session.exec(stmt)

        user = result.first()

        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        return user
    

    async def get_all_users(self, session: AsyncSession):
        stmt = select(User)
        result = await session.exec(stmt)

        return result.all()

    
    async def get_user_by_login(self, session: AsyncSession, login: str):
        stmt = select(User).where(User.login == login)
        result = await session.exec(stmt)

        user = result.first()

        return user


    async def create_user(self, session: AsyncSession, user_schema: UserSignUpModel):
        user_data = user_schema.model_dump()

        if await self.get_user_by_login(session, user_data["login"]):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User already exists")

        pwd_hash = generate_password_hash(user_data["pwd"])
        user_data["pwd"] = pwd_hash

        user = User(login=user_data["login"], pwd=user_data["pwd"])
        del user_data["login"]
        del user_data["pwd"]

        try:
            if user_data["admin_password"] == AppSettings.ADMIN_PASSWORD:
                user.role = "admin"
                del user_data["admin_password"]
        except:
            pass

        employee = Employee(**user_data)
        session.add(user)
        await session.commit()
        employee.id = user.id
        session.add(employee)
        await session.commit()
        return user
    

    async def verify_user(self, session: AsyncSession, id: int, verified_val: bool) -> bool:
        stmt = update(User).where(User.id == id).values(verified=verified_val)
        await session.exec(stmt)
        await session.commit()
        return {"message": "User verified"}
    

    async def delete_user(self, session: AsyncSession, id: int) -> bool:
        user = await self.get_user(session, id)

        if user.role == "admin":
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You cannot delete an admin user")

        stmt = delete(Employee).where(Employee.id == user.id)
        await session.exec(stmt)
        stmt = delete(User).where(User.id == id)
        await session.exec(stmt)
        await session.commit()
        return {"message": "User deleted"}
    

    async def get_all_admins(self, session: AsyncSession):
        stmt = select(User).where(User.role == "admin")
        result = await session.exec(stmt)
        return result.all()


    async def promote_to_admin(self, session: AsyncSession, id: int):
        stmt = update(User).where(User.id == id).values(role="admin")
        await session.exec(stmt)
        await session.commit()
        return {"message": "User promoted to admin"}