from fastapi import Request, status, Depends
from fastapi.exceptions import HTTPException
from fastapi.security import HTTPBearer
from sqlmodel.ext.asyncio.session import AsyncSession
from typing import List

from src.database.main import get_session
from .service import AuthService
from .models import User
from .utils import verify_password

import base64


auth_service = AuthService()

class AuthBearer(HTTPBearer):

    def __init__(self, auto_error: bool = True):
        super().__init__(auto_error=auto_error)

    
    async def __call__ (self, request: Request, session: AsyncSession = Depends(get_session)):
        try:
            type, raw_data = request.headers.get("Authorization").split(" ")
            
            if type.lower() != "basic":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            
            decoded_data = base64.b64decode(raw_data).decode("utf-8")
            
            if decoded_data.count(":") != 1:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            
            login, pwd = decoded_data.split(":")
            if not await self.validate_user(login, pwd, session):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail="Not authenticated"
                )
            
            return login

        except Exception as error:
            print(error)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Something went wrong. Please try again later."
            )

    async def validate_user(self, login: str, pwd: str, session: AsyncSession):
        user = await auth_service.get_user_by_login(session, login)
            
        if not user:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authenticated")

        return verify_password(pwd, user.pwd)


async def get_current_user(
        session: AsyncSession = Depends(get_session),
        bearer: str = Depends(AuthBearer())
    ):
    user = await auth_service.get_user_by_login(session, bearer)
    return user


class RoleCheck():
    def __init__(self, roles: List[str]):
        self.valid_roles = roles
    

    def __call__(self, user: User = Depends(get_current_user)):
        if user.role not in self.valid_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="You are allowed to perform this action"
            )
        
        return True