from sqlmodel import SQLModel, Field, Column, Relationship
from sqlalchemy.dialects import postgresql as pg


from typing import List
import uuid

class User(SQLModel, table=True):
    __tablename__ = "users"

    id: int = Field(
        sa_column=Column(
            pg.INTEGER, 
            primary_key=True,
            autoincrement=True
        )
    )

    login: str = Field(sa_column=Column(pg.VARCHAR, nullable=False, unique=True), exclude=True)
    pwd: str = Field(sa_column=Column(pg.VARCHAR, nullable=False), exclude=True)
    verified: bool = Field(sa_column=Column(pg.BOOLEAN, nullable=False, default=False))
    role: str = Field(sa_column=Column(pg.ENUM("user", "admin", name="roles"), nullable=False, default="user"))

    employee: List["Employee"] = Relationship(back_populates="user")