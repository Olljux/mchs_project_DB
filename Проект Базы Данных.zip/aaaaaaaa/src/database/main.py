from fastapi import Depends
from sqlmodel import create_engine, SQLModel
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.orm import sessionmaker
from src.config import AppSettings

from src.auth.utils import generate_password_hash

engine = AsyncEngine(
    create_engine(
        url = AppSettings.DB_URL,
        echo=True,
    )
)

async def init_db():
    async with engine.begin() as conn:
        from src.auth.models import User
        from src.employee.models import Employee

        await conn.run_sync(SQLModel.metadata.create_all)


async def get_session() -> AsyncSession: # type: ignore
    Session = sessionmaker(
        bind=engine, 
        class_=AsyncSession,
        expire_on_commit=False
    )

    async with Session() as session:
        yield session